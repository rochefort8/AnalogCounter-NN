#!/bin/bash
# increase_image

f=$1

max=2

rm -rf $f"_"*.bmp

# contrast
cp $f".bmp" $f"_0_000.bmp"
for ((i=0; i < $max; i++)); do
    let ii=$i+1 
    n0=$(printf %03d $i)
    n1=$(printf %03d $ii)
    convert $f"_0_"$n0.bmp -contrast $f"_0_"$n1.bmp
done

# contrast
cp $f".bmp" $f"_1_000.bmp"
for ((i=0; i < $max; i++)); do
    let ii=$i+1 
    n0=$(printf %03d $i)
    n1=$(printf %03d $ii)
    convert $f"_1_"$n0.bmp +contrast $f"_1_"$n1.bmp
done

# blur
#cp $f".bmp" $f"_2_000.bmp"
#for ((i=0; i < 2; i++)); do
#    let ii=$i+1 
#    n0=$(printf %03d $i)
#    n1=$(printf %03d $ii)    
#    convert $f"_2_"$n0.bmp -blur 10x2 $f"_2_"$n1.bmp    
#done

cp $f".bmp" $f"_3_000.bmp"
for ((i=0; i < $max; i++)); do
    let ii=$i+1 
    n0=$(printf %03d $i)
    n1=$(printf %03d $ii)    
    convert $f"_3_"$n0.bmp -gamma 0.1 $f"_3_"$n1.bmp    
done

cp $f".bmp" $f"_4_000.bmp"
for ((i=0; i < $max; i++)); do
    let ii=$i+1 
    n0=$(printf %03d $i)
    n1=$(printf %03d $ii)    
    convert $f"_4_"$n0.bmp -gamma 0.1 $f"_4_"$n1.bmp    
done


